// Copyright (c) 2014-2017 The Dash Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include "activexhnode.h"
#include "consensus/consensus.h"
#include "xhnode.h"
#include "xhnode-sync.h"
#include "xhnode-payments.h"
#include "xhnodeman.h"
#include "protocol.h"

extern CWallet *pwalletMain;

// Keep track of the active XHnode
CActiveXHnode activeXHnode;

void CActiveXHnode::ManageState() {
    LogPrint("xhnode", "CActiveXHnode::ManageState -- Start\n");
    if (!fXHNode) {
        LogPrint("xhnode", "CActiveXHnode::ManageState -- Not a xhnode, returning\n");
        return;
    }

    if (Params().NetworkIDString() != CBaseChainParams::REGTEST && !xhnodeSync.IsBlockchainSynced()) {
        nState = ACTIVE_XHNODE_SYNC_IN_PROCESS;
        LogPrintf("CActiveXHnode::ManageState -- %s: %s\n", GetStateString(), GetStatus());
        return;
    }

    if (nState == ACTIVE_XHNODE_SYNC_IN_PROCESS) {
        nState = ACTIVE_XHNODE_INITIAL;
    }

    LogPrint("xhnode", "CActiveXHnode::ManageState -- status = %s, type = %s, pinger enabled = %d\n",
             GetStatus(), GetTypeString(), fPingerEnabled);

    if (eType == XHNODE_UNKNOWN) {
        ManageStateInitial();
    }

    if (eType == XHNODE_REMOTE) {
        ManageStateRemote();
    } else if (eType == XHNODE_LOCAL) {
        // Try Remote Start first so the started local xhnode can be restarted without recreate xhnode broadcast.
        ManageStateRemote();
        if (nState != ACTIVE_XHNODE_STARTED)
            ManageStateLocal();
    }

    SendXHnodePing();
}

std::string CActiveXHnode::GetStateString() const {
    switch (nState) {
        case ACTIVE_XHNODE_INITIAL:
            return "INITIAL";
        case ACTIVE_XHNODE_SYNC_IN_PROCESS:
            return "SYNC_IN_PROCESS";
        case ACTIVE_XHNODE_INPUT_TOO_NEW:
            return "INPUT_TOO_NEW";
        case ACTIVE_XHNODE_NOT_CAPABLE:
            return "NOT_CAPABLE";
        case ACTIVE_XHNODE_STARTED:
            return "STARTED";
        default:
            return "UNKNOWN";
    }
}

std::string CActiveXHnode::GetStatus() const {
    switch (nState) {
        case ACTIVE_XHNODE_INITIAL:
            return "Node just started, not yet activated";
        case ACTIVE_XHNODE_SYNC_IN_PROCESS:
            return "Sync in progress. Must wait until sync is complete to start XHnode";
        case ACTIVE_XHNODE_INPUT_TOO_NEW:
            return strprintf("XHnode input must have at least %d confirmations",
                             Params().GetConsensus().nXHnodeMinimumConfirmations);
        case ACTIVE_XHNODE_NOT_CAPABLE:
            return "Not capable xhnode: " + strNotCapableReason;
        case ACTIVE_XHNODE_STARTED:
            return "XHnode successfully started";
        default:
            return "Unknown";
    }
}

std::string CActiveXHnode::GetTypeString() const {
    std::string strType;
    switch (eType) {
        case XHNODE_UNKNOWN:
            strType = "UNKNOWN";
            break;
        case XHNODE_REMOTE:
            strType = "REMOTE";
            break;
        case XHNODE_LOCAL:
            strType = "LOCAL";
            break;
        default:
            strType = "UNKNOWN";
            break;
    }
    return strType;
}

bool CActiveXHnode::SendXHnodePing() {
    if (!fPingerEnabled) {
        LogPrint("xhnode",
                 "CActiveXHnode::SendXHnodePing -- %s: xhnode ping service is disabled, skipping...\n",
                 GetStateString());
        return false;
    }

    if (!mnodeman.Has(vin)) {
        strNotCapableReason = "XHnode not in xhnode list";
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        LogPrintf("CActiveXHnode::SendXHnodePing -- %s: %s\n", GetStateString(), strNotCapableReason);
        return false;
    }

    CXHnodePing mnp(vin);
    if (!mnp.Sign(keyXHnode, pubKeyXHnode)) {
        LogPrintf("CActiveXHnode::SendXHnodePing -- ERROR: Couldn't sign XHnode Ping\n");
        return false;
    }

    // Update lastPing for our xhnode in XHnode list
    if (mnodeman.IsXHnodePingedWithin(vin, XHNODE_MIN_MNP_SECONDS, mnp.sigTime)) {
        LogPrintf("CActiveXHnode::SendXHnodePing -- Too early to send XHnode Ping\n");
        return false;
    }

    mnodeman.SetXHnodeLastPing(vin, mnp);

    LogPrintf("CActiveXHnode::SendXHnodePing -- Relaying ping, collateral=%s\n", vin.ToString());
    mnp.Relay();

    return true;
}

void CActiveXHnode::ManageStateInitial() {
    LogPrint("xhnode", "CActiveXHnode::ManageStateInitial -- status = %s, type = %s, pinger enabled = %d\n",
             GetStatus(), GetTypeString(), fPingerEnabled);

    // Check that our local network configuration is correct
    if (!fListen) {
        // listen option is probably overwritten by smth else, no good
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        strNotCapableReason = "XHnode must accept connections from outside. Make sure listen configuration option is not overwritten by some another parameter.";
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
        return;
    }

    bool fFoundLocal = false;
    {
        LOCK(cs_vNodes);

        // First try to find whatever local address is specified by externalip option
        fFoundLocal = GetLocal(service) && CXHnode::IsValidNetAddr(service);
        if (!fFoundLocal) {
            // nothing and no live connections, can't do anything for now
            if (vNodes.empty()) {
                nState = ACTIVE_XHNODE_NOT_CAPABLE;
                strNotCapableReason = "Can't detect valid external address. Will retry when there are some connections available.";
                LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
                return;
            }
            // We have some peers, let's try to find our local address from one of them
            BOOST_FOREACH(CNode * pnode, vNodes)
            {
                if (pnode->fSuccessfullyConnected && pnode->addr.IsIPv4()) {
                    fFoundLocal = GetLocal(service, &pnode->addr) && CXHnode::IsValidNetAddr(service);
                    if (fFoundLocal) break;
                }
            }
        }
    }

    if (!fFoundLocal) {
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        strNotCapableReason = "Can't detect valid external address. Please consider using the externalip configuration option if problem persists. Make sure to use IPv4 address only.";
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
        return;
    }

    int mainnetDefaultPort = Params(CBaseChainParams::MAIN).GetDefaultPort();
    if (Params().NetworkIDString() == CBaseChainParams::MAIN) {
        if (service.GetPort() != mainnetDefaultPort) {
            nState = ACTIVE_XHNODE_NOT_CAPABLE;
            strNotCapableReason = strprintf("Invalid port: %u - only %d is supported on mainnet.", service.GetPort(),
                                            mainnetDefaultPort);
            LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }
    } else if (service.GetPort() == mainnetDefaultPort) {
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        strNotCapableReason = strprintf("Invalid port: %u - %d is only supported on mainnet.", service.GetPort(),
                                        mainnetDefaultPort);
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
        return;
    }

    LogPrintf("CActiveXHnode::ManageStateInitial -- Checking inbound connection to '%s'\n", service.ToString());
    //TODO
    if (!ConnectNode(CAddress(service, NODE_NETWORK), NULL, false, true)) {
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        strNotCapableReason = "Could not connect to " + service.ToString();
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: %s\n", GetStateString(), strNotCapableReason);
        return;
    }

    // Default to REMOTE
    eType = XHNODE_REMOTE;

    // Check if wallet funds are available
    if (!pwalletMain) {
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: Wallet not available\n", GetStateString());
        return;
    }

    if (pwalletMain->IsLocked()) {
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: Wallet is locked\n", GetStateString());
        return;
    }

    if (pwalletMain->GetBalance() < XHNODE_COIN_REQUIRED * COIN) {
        LogPrintf("CActiveXHnode::ManageStateInitial -- %s: Wallet balance is < 1000 BHC\n", GetStateString());
        return;
    }

    // Choose coins to use
    CPubKey pubKeyCollateral;
    CKey keyCollateral;

    // If collateral is found switch to LOCAL mode
    if (pwalletMain->GetXHnodeVinAndKeys(vin, pubKeyCollateral, keyCollateral)) {
        eType = XHNODE_LOCAL;
    }

    LogPrint("xhnode", "CActiveXHnode::ManageStateInitial -- End status = %s, type = %s, pinger enabled = %d\n",
             GetStatus(), GetTypeString(), fPingerEnabled);
}

void CActiveXHnode::ManageStateRemote() {
    LogPrint("xhnode",
             "CActiveXHnode::ManageStateRemote -- Start status = %s, type = %s, pinger enabled = %d, pubKeyXHnode.GetID() = %s\n",
             GetStatus(), fPingerEnabled, GetTypeString(), pubKeyXHnode.GetID().ToString());

    mnodeman.CheckXHnode(pubKeyXHnode);
    xhnode_info_t infoMn = mnodeman.GetXHnodeInfo(pubKeyXHnode);
    if (infoMn.fInfoValid) {
        if (infoMn.nProtocolVersion < mnpayments.GetMinXHnodePaymentsProto()) {
            nState = ACTIVE_XHNODE_NOT_CAPABLE;
            strNotCapableReason = "Invalid protocol version";
            LogPrintf("CActiveXHnode::ManageStateRemote -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }
        if (service != infoMn.addr) {
            nState = ACTIVE_XHNODE_NOT_CAPABLE;
            // LogPrintf("service: %s\n", service.ToString());
            // LogPrintf("infoMn.addr: %s\n", infoMn.addr.ToString());
            strNotCapableReason = "Broadcasted IP doesn't match our external address. Make sure you issued a new broadcast if IP of this xhnode changed recently.";
            LogPrintf("CActiveXHnode::ManageStateRemote -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }
        if (!CXHnode::IsValidStateForAutoStart(infoMn.nActiveState)) {
            nState = ACTIVE_XHNODE_NOT_CAPABLE;
            strNotCapableReason = strprintf("XHnode in %s state", CXHnode::StateToString(infoMn.nActiveState));
            LogPrintf("CActiveXHnode::ManageStateRemote -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }
        if (nState != ACTIVE_XHNODE_STARTED) {
            LogPrintf("CActiveXHnode::ManageStateRemote -- STARTED!\n");
            vin = infoMn.vin;
            service = infoMn.addr;
            fPingerEnabled = true;
            nState = ACTIVE_XHNODE_STARTED;
        }
    } else {
        nState = ACTIVE_XHNODE_NOT_CAPABLE;
        strNotCapableReason = "XHnode not in xhnode list";
        LogPrintf("CActiveXHnode::ManageStateRemote -- %s: %s\n", GetStateString(), strNotCapableReason);
    }
}

void CActiveXHnode::ManageStateLocal() {
    LogPrint("xhnode", "CActiveXHnode::ManageStateLocal -- status = %s, type = %s, pinger enabled = %d\n",
             GetStatus(), GetTypeString(), fPingerEnabled);
    if (nState == ACTIVE_XHNODE_STARTED) {
        return;
    }

    // Choose coins to use
    CPubKey pubKeyCollateral;
    CKey keyCollateral;

    if (pwalletMain->GetXHnodeVinAndKeys(vin, pubKeyCollateral, keyCollateral)) {
        int nInputAge = GetInputAge(vin);
        if (nInputAge < Params().GetConsensus().nXHnodeMinimumConfirmations) {
            nState = ACTIVE_XHNODE_INPUT_TOO_NEW;
            strNotCapableReason = strprintf(_("%s - %d confirmations"), GetStatus(), nInputAge);
            LogPrintf("CActiveXHnode::ManageStateLocal -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }

        {
            LOCK(pwalletMain->cs_wallet);
            pwalletMain->LockCoin(vin.prevout);
        }

        CXHnodeBroadcast mnb;
        std::string strError;
        if (!CXHnodeBroadcast::Create(vin, service, keyCollateral, pubKeyCollateral, keyXHnode,
                                     pubKeyXHnode, strError, mnb)) {
            nState = ACTIVE_XHNODE_NOT_CAPABLE;
            strNotCapableReason = "Error creating mastenode broadcast: " + strError;
            LogPrintf("CActiveXHnode::ManageStateLocal -- %s: %s\n", GetStateString(), strNotCapableReason);
            return;
        }

        fPingerEnabled = true;
        nState = ACTIVE_XHNODE_STARTED;

        //update to xhnode list
        LogPrintf("CActiveXHnode::ManageStateLocal -- Update XHnode List\n");
        mnodeman.UpdateXHnodeList(mnb);
        mnodeman.NotifyXHnodeUpdates();

        //send to all peers
        LogPrintf("CActiveXHnode::ManageStateLocal -- Relay broadcast, vin=%s\n", vin.ToString());
        mnb.RelayXHNode();
    }
}
